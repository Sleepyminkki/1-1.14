import React from 'react';
import { useState } from 'react';

const StatisticLine = (props) => {
  let statValues = props.value;

  if (props.text === "average" || props.text === "positive") {
    statValues = props.value;
  }

  const allValues = statValues !== undefined ? statValues : 0;

  const statTable = {
    width: "20%"
  }

  const textStyle = {
    textAlign: "left"
  }

  const valueStyle = {
    textAlign: "right"
  }
  
  return (
    <div>
      <table style={statTable}>
        <tbody>
          <tr>
           <th style={textStyle}>
            {props.text} 
           </th>   
            <td style={valueStyle}>
             {props.good ||
             props.neutral ||
             props.bad ||
             allValues}
            </td>
          </tr>
         </tbody>
      </table>
    </div>
  )
}

const Statistics = (props) => {
  const all = props.good + props.neutral + props.bad;
  const average = (props.ave / all).toFixed(1);
  const positive = ((props.good / all) * 100).toFixed(1);

  if (all === 0) {
    return (
      <div>
      <p>No feedback given</p>
      </div>
    )
  } else {

    return (
     <div>
      <StatisticLine text="good" good={props.good} />
      <StatisticLine text="neutral" neutral={props.neutral} /> 
      <StatisticLine text="bad" bad={props.bad} />
      <StatisticLine text="all" value={all} />
      <StatisticLine text="average" value={average} />
      <StatisticLine text="positive" value={positive + "%"} />
     </div>
  )
  }
}

const Button = (props) => {
  return (
    <div>
      <button onClick={props.handleGoodClick}>Good</button>
      <button onClick={props.handleNeutralClick}>Neutral</button>
      <button onClick={props.handleBadClick}>Bad</button>
    </div>
  )
}

const App = () => {
  
  const [good, setGood] = useState(0);
  const [neutral, setNeutral] = useState(0);
  const [bad, setBad] = useState(0);
  const [ave, setAve] = useState(0);

  const handleGoodClick = () => {
    setGood(good + 1);
    setAve(ave + 1);
  }

  const handleNeutralClick = () => {
    setNeutral(neutral + 1);
  }

  const handleBadClick = () => {
    setBad(bad + 1);
    setAve(ave - 1);
  }

  return (
    <div>

      <h1>give feedback</h1>

      <Button handleGoodClick={handleGoodClick}
       handleNeutralClick={handleNeutralClick}
       handleBadClick={handleBadClick}/>

      <h1>statistics</h1>

      <Statistics good={good} 
      neutral={neutral} 
      bad={bad} 
      ave={ave}/>
    </div>
  )
}

export default App;
